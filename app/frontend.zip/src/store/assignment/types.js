export const ASSIGNMENT_LOADING  = "assignm/loading";
export const ASSIGNMENT_ERROR = "assignm/error";
export const ASSIGNMENT_CREATE = "assignm/create";
export const ASSIGNMENT_DELETE = "assignm/delete";
export const ASSIGNMENT_UPDATE = "assignm/update";
export const ASSIGNMENT_GET_ALL = "assignm/get/all";
export const ASSIGNMENT_TOUST_CLEANER = "assignm/toust/cleaner";