export const COURSE_LOADING  = "course/loading";
export const COURSE_ERROR = "course/error";
export const COURSE_CREATE = "course/create";
export const COURSE_DELETE = "course/delete";
export const COURSE_UPDATE = "course/update";
export const COURSE_GET_ALL = "course/get/all";
export const COURSE_TOUST_CLEANER = "course/toust/cleaner";
