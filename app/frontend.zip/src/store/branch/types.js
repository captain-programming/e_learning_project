export const BRANCH_LOADING  = "branch/loading";
export const BRANCH_ERROR = "branch/error";
export const BRANCH_CREATE = "branch/create";
export const BRANCH_DELETE = "branch/delete";
export const BRANCH_UPDATE = "branch/update";
export const BRANCH_GET_All = "branch/get/all";
export const BRANCH_TOUST_CLEANER = "branch/toust/cleaner";
export const BRANCH_SINGLE_DETAILS = "brnach/single/details"
