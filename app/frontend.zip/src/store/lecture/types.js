export const LECTURE_LOADING  = "lecture/loading";
export const LECTURE_ERROR = "lecture/error";
export const LECTURE_CREATE = "lecture/create";
export const LECTURE_DELETE = "lecture/delete";
export const LECTURE_UPDATE = "lecture/update";
export const LECTURE_GET_ALL = "lecture/get/all";
export const LECTURE_TOUST_CLEANER = "lecture/toust/cleaner";
