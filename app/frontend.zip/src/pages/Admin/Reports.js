import { View, Text } from 'react-native'
import React from 'react'

const Reports = () => {
  return (
    <View>
      <Text>Reports</Text>
    </View>
  )
}

export default Reports