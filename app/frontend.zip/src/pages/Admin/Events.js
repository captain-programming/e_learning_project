import { View, Text } from 'react-native'
import React from 'react'

const Events = () => {
  return (
    <View>
      <Text>Events</Text>
    </View>
  )
}

export default Events