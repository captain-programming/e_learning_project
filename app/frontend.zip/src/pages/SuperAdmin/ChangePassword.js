import { View, Text } from 'react-native'
import React from 'react'

const ChangePassword = () => {
  return (
    <View>
      <Text>ChangePassword</Text>
    </View>
  )
}

export default ChangePassword