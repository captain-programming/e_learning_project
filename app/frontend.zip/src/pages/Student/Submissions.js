import { View, Text } from 'react-native'
import React from 'react'

const Submissions = () => {
  return (
    <View>
      <Text>Submissions</Text>
    </View>
  )
}

export default Submissions