import { View, Text } from 'react-native'
import React from 'react'

const Courses = () => {
  return (
    <View>
      <Text>Courses</Text>
    </View>
  )
}

export default Courses