import { View, Text } from 'react-native'
import React from 'react'

const Groups = () => {
  return (
    <View>
      <Text>Groups</Text>
    </View>
  )
}

export default Groups