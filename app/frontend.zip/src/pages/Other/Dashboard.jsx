import { View, Text } from 'react-native'
import React from 'react'

const Dashboard = () => {
  return (
    <View>
      <Text>Not access for this side</Text>
    </View>
  )
}

export default Dashboard;